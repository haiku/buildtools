var NAVTREE =
[
  [ "PPL", "index.html", [
    [ "General Information on the PPL", "index.html", null ],
    [ "Related Pages", "pages.html", [
      [ "GNU General Public License", "GPL.html", null ],
      [ "GNU Free Documentation License", "GFDL.html", null ]
    ] ],
    [ "Modules", "modules.html", [
      [ "C++ Language Interface", "group__PPL__CXX__interface.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "Parma_Polyhedra_Library::PIP_Tree_Node::Artificial_Parameter", "classParma__Polyhedra__Library_1_1PIP__Tree__Node_1_1Artificial__Parameter.html", null ],
      [ "Parma_Polyhedra_Library::BD_Shape< T >", "classParma__Polyhedra__Library_1_1BD__Shape.html", null ],
      [ "Parma_Polyhedra_Library::BHRZ03_Certificate", "classParma__Polyhedra__Library_1_1BHRZ03__Certificate.html", null ],
      [ "Parma_Polyhedra_Library::Box< ITV >", "classParma__Polyhedra__Library_1_1Box.html", null ],
      [ "Parma_Polyhedra_Library::C_Polyhedron", "classParma__Polyhedra__Library_1_1C__Polyhedron.html", null ],
      [ "Parma_Polyhedra_Library::Checked_Number< T, Policy >", "classParma__Polyhedra__Library_1_1Checked__Number.html", null ],
      [ "Parma_Polyhedra_Library::Variable::Compare", "structParma__Polyhedra__Library_1_1Variable_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::BHRZ03_Certificate::Compare", "structParma__Polyhedra__Library_1_1BHRZ03__Certificate_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::H79_Certificate::Compare", "structParma__Polyhedra__Library_1_1H79__Certificate_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Certificate::Compare", "structParma__Polyhedra__Library_1_1Grid__Certificate_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::Congruence", "classParma__Polyhedra__Library_1_1Congruence.html", null ],
      [ "Parma_Polyhedra_Library::Congruence_System", "classParma__Polyhedra__Library_1_1Congruence__System.html", null ],
      [ "Parma_Polyhedra_Library::Congruences_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Congruences__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Constraint_System::const_iterator", "classParma__Polyhedra__Library_1_1Constraint__System_1_1const__iterator.html", null ],
      [ "Parma_Polyhedra_Library::Generator_System::const_iterator", "classParma__Polyhedra__Library_1_1Generator__System_1_1const__iterator.html", null ],
      [ "Parma_Polyhedra_Library::Congruence_System::const_iterator", "classParma__Polyhedra__Library_1_1Congruence__System_1_1const__iterator.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Generator_System::const_iterator", "classParma__Polyhedra__Library_1_1Grid__Generator__System_1_1const__iterator.html", null ],
      [ "Parma_Polyhedra_Library::Constraint", "classParma__Polyhedra__Library_1_1Constraint.html", null ],
      [ "Parma_Polyhedra_Library::Constraint_System", "classParma__Polyhedra__Library_1_1Constraint__System.html", null ],
      [ "Parma_Polyhedra_Library::Constraints_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Constraints__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Determinate< PSET >", "classParma__Polyhedra__Library_1_1Determinate.html", null ],
      [ "Parma_Polyhedra_Library::Domain_Product< D1, D2 >", "classParma__Polyhedra__Library_1_1Domain__Product.html", null ],
      [ "Parma_Polyhedra_Library::Generator", "classParma__Polyhedra__Library_1_1Generator.html", null ],
      [ "Parma_Polyhedra_Library::Generator_System", "classParma__Polyhedra__Library_1_1Generator__System.html", null ],
      [ "Parma_Polyhedra_Library::GMP_Integer", "classParma__Polyhedra__Library_1_1GMP__Integer.html", null ],
      [ "Parma_Polyhedra_Library::Grid", "classParma__Polyhedra__Library_1_1Grid.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Certificate", "classParma__Polyhedra__Library_1_1Grid__Certificate.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Generator", "classParma__Polyhedra__Library_1_1Grid__Generator.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Generator_System", "classParma__Polyhedra__Library_1_1Grid__Generator__System.html", null ],
      [ "Parma_Polyhedra_Library::H79_Certificate", "classParma__Polyhedra__Library_1_1H79__Certificate.html", null ],
      [ "Parma_Polyhedra_Library::Interval< Boundary, Info >", "classParma__Polyhedra__Library_1_1Interval.html", null ],
      [ "Parma_Polyhedra_Library::Is_Checked< T >", "structParma__Polyhedra__Library_1_1Is__Checked.html", null ],
      [ "Parma_Polyhedra_Library::Is_Checked< Checked_Number< T, P > >", "structParma__Polyhedra__Library_1_1Is__Checked_3_01Checked__Number_3_01T_00_01P_01_4_01_4.html", null ],
      [ "Parma_Polyhedra_Library::Is_Native_Or_Checked< T >", "structParma__Polyhedra__Library_1_1Is__Native__Or__Checked.html", null ],
      [ "Parma_Polyhedra_Library::Linear_Expression", "classParma__Polyhedra__Library_1_1Linear__Expression.html", null ],
      [ "Parma_Polyhedra_Library::MIP_Problem", "classParma__Polyhedra__Library_1_1MIP__Problem.html", null ],
      [ "Parma_Polyhedra_Library::NNC_Polyhedron", "classParma__Polyhedra__Library_1_1NNC__Polyhedron.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Solution_Node::No_Constraints", "structParma__Polyhedra__Library_1_1PIP__Solution__Node_1_1No__Constraints.html", null ],
      [ "Parma_Polyhedra_Library::No_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1No__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Octagonal_Shape< T >", "classParma__Polyhedra__Library_1_1Octagonal__Shape.html", null ],
      [ "Parma_Polyhedra_Library::Partially_Reduced_Product< D1, D2, R >", "classParma__Polyhedra__Library_1_1Partially__Reduced__Product.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Decision_Node", "classParma__Polyhedra__Library_1_1PIP__Decision__Node.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Problem", "classParma__Polyhedra__Library_1_1PIP__Problem.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Solution_Node", "classParma__Polyhedra__Library_1_1PIP__Solution__Node.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Tree_Node", "classParma__Polyhedra__Library_1_1PIP__Tree__Node.html", null ],
      [ "Parma_Polyhedra_Library::Pointset_Powerset< PSET >", "classParma__Polyhedra__Library_1_1Pointset__Powerset.html", null ],
      [ "Parma_Polyhedra_Library::Poly_Con_Relation", "classParma__Polyhedra__Library_1_1Poly__Con__Relation.html", null ],
      [ "Parma_Polyhedra_Library::Poly_Gen_Relation", "classParma__Polyhedra__Library_1_1Poly__Gen__Relation.html", null ],
      [ "Parma_Polyhedra_Library::Polyhedron", "classParma__Polyhedra__Library_1_1Polyhedron.html", null ],
      [ "Parma_Polyhedra_Library::Powerset< D >", "classParma__Polyhedra__Library_1_1Powerset.html", null ],
      [ "Parma_Polyhedra_Library::Recycle_Input", "structParma__Polyhedra__Library_1_1Recycle__Input.html", null ],
      [ "Parma_Polyhedra_Library::Shape_Preserving_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Smash_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Smash__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Throwable", "classParma__Polyhedra__Library_1_1Throwable.html", null ],
      [ "Parma_Polyhedra_Library::Variable", "classParma__Polyhedra__Library_1_1Variable.html", null ],
      [ "Parma_Polyhedra_Library::Variables_Set", "classParma__Polyhedra__Library_1_1Variables__Set.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "Parma_Polyhedra_Library::BD_Shape< T >", "classParma__Polyhedra__Library_1_1BD__Shape.html", null ],
      [ "Parma_Polyhedra_Library::BHRZ03_Certificate", "classParma__Polyhedra__Library_1_1BHRZ03__Certificate.html", null ],
      [ "Parma_Polyhedra_Library::Box< ITV >", "classParma__Polyhedra__Library_1_1Box.html", null ],
      [ "Parma_Polyhedra_Library::Checked_Number< T, Policy >", "classParma__Polyhedra__Library_1_1Checked__Number.html", null ],
      [ "Parma_Polyhedra_Library::Variable::Compare", "structParma__Polyhedra__Library_1_1Variable_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::BHRZ03_Certificate::Compare", "structParma__Polyhedra__Library_1_1BHRZ03__Certificate_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::H79_Certificate::Compare", "structParma__Polyhedra__Library_1_1H79__Certificate_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Certificate::Compare", "structParma__Polyhedra__Library_1_1Grid__Certificate_1_1Compare.html", null ],
      [ "Parma_Polyhedra_Library::Congruence", "classParma__Polyhedra__Library_1_1Congruence.html", null ],
      [ "Parma_Polyhedra_Library::Congruence_System", "classParma__Polyhedra__Library_1_1Congruence__System.html", null ],
      [ "Parma_Polyhedra_Library::Congruences_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Congruences__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Constraint_System::const_iterator", "classParma__Polyhedra__Library_1_1Constraint__System_1_1const__iterator.html", null ],
      [ "Parma_Polyhedra_Library::Generator_System::const_iterator", "classParma__Polyhedra__Library_1_1Generator__System_1_1const__iterator.html", [
        [ "Parma_Polyhedra_Library::Grid_Generator_System::const_iterator", "classParma__Polyhedra__Library_1_1Grid__Generator__System_1_1const__iterator.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::Congruence_System::const_iterator", "classParma__Polyhedra__Library_1_1Congruence__System_1_1const__iterator.html", null ],
      [ "Parma_Polyhedra_Library::Constraint", "classParma__Polyhedra__Library_1_1Constraint.html", null ],
      [ "Parma_Polyhedra_Library::Constraint_System", "classParma__Polyhedra__Library_1_1Constraint__System.html", null ],
      [ "Parma_Polyhedra_Library::Constraints_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Constraints__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Determinate< PSET >", "classParma__Polyhedra__Library_1_1Determinate.html", null ],
      [ "Parma_Polyhedra_Library::Domain_Product< D1, D2 >", "classParma__Polyhedra__Library_1_1Domain__Product.html", null ],
      [ "Parma_Polyhedra_Library::Generator", "classParma__Polyhedra__Library_1_1Generator.html", [
        [ "Parma_Polyhedra_Library::Grid_Generator", "classParma__Polyhedra__Library_1_1Grid__Generator.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::Generator_System", "classParma__Polyhedra__Library_1_1Generator__System.html", [
        [ "Parma_Polyhedra_Library::Grid_Generator_System", "classParma__Polyhedra__Library_1_1Grid__Generator__System.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::GMP_Integer", "classParma__Polyhedra__Library_1_1GMP__Integer.html", null ],
      [ "Parma_Polyhedra_Library::Grid", "classParma__Polyhedra__Library_1_1Grid.html", null ],
      [ "Parma_Polyhedra_Library::Grid_Certificate", "classParma__Polyhedra__Library_1_1Grid__Certificate.html", null ],
      [ "Parma_Polyhedra_Library::H79_Certificate", "classParma__Polyhedra__Library_1_1H79__Certificate.html", null ],
      [ "Parma_Polyhedra_Library::Interval< Boundary, Info >", "classParma__Polyhedra__Library_1_1Interval.html", null ],
      [ "Parma_Polyhedra_Library::Is_Checked< T >", "structParma__Polyhedra__Library_1_1Is__Checked.html", null ],
      [ "Parma_Polyhedra_Library::Is_Checked< Checked_Number< T, P > >", "structParma__Polyhedra__Library_1_1Is__Checked_3_01Checked__Number_3_01T_00_01P_01_4_01_4.html", null ],
      [ "Parma_Polyhedra_Library::Is_Native_Or_Checked< T >", "structParma__Polyhedra__Library_1_1Is__Native__Or__Checked.html", null ],
      [ "Parma_Polyhedra_Library::Linear_Expression", "classParma__Polyhedra__Library_1_1Linear__Expression.html", [
        [ "Parma_Polyhedra_Library::PIP_Tree_Node::Artificial_Parameter", "classParma__Polyhedra__Library_1_1PIP__Tree__Node_1_1Artificial__Parameter.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::MIP_Problem", "classParma__Polyhedra__Library_1_1MIP__Problem.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Solution_Node::No_Constraints", "structParma__Polyhedra__Library_1_1PIP__Solution__Node_1_1No__Constraints.html", null ],
      [ "Parma_Polyhedra_Library::No_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1No__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Octagonal_Shape< T >", "classParma__Polyhedra__Library_1_1Octagonal__Shape.html", null ],
      [ "Parma_Polyhedra_Library::Partially_Reduced_Product< D1, D2, R >", "classParma__Polyhedra__Library_1_1Partially__Reduced__Product.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Problem", "classParma__Polyhedra__Library_1_1PIP__Problem.html", null ],
      [ "Parma_Polyhedra_Library::PIP_Tree_Node", "classParma__Polyhedra__Library_1_1PIP__Tree__Node.html", [
        [ "Parma_Polyhedra_Library::PIP_Decision_Node", "classParma__Polyhedra__Library_1_1PIP__Decision__Node.html", null ],
        [ "Parma_Polyhedra_Library::PIP_Solution_Node", "classParma__Polyhedra__Library_1_1PIP__Solution__Node.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::Poly_Con_Relation", "classParma__Polyhedra__Library_1_1Poly__Con__Relation.html", null ],
      [ "Parma_Polyhedra_Library::Poly_Gen_Relation", "classParma__Polyhedra__Library_1_1Poly__Gen__Relation.html", null ],
      [ "Parma_Polyhedra_Library::Polyhedron", "classParma__Polyhedra__Library_1_1Polyhedron.html", [
        [ "Parma_Polyhedra_Library::C_Polyhedron", "classParma__Polyhedra__Library_1_1C__Polyhedron.html", null ],
        [ "Parma_Polyhedra_Library::NNC_Polyhedron", "classParma__Polyhedra__Library_1_1NNC__Polyhedron.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::Powerset< D >", "classParma__Polyhedra__Library_1_1Powerset.html", null ],
      [ "Parma_Polyhedra_Library::Powerset< Parma_Polyhedra_Library::Determinate< PSET > >", "classParma__Polyhedra__Library_1_1Powerset.html", [
        [ "Parma_Polyhedra_Library::Pointset_Powerset< PSET >", "classParma__Polyhedra__Library_1_1Pointset__Powerset.html", null ]
      ] ],
      [ "Parma_Polyhedra_Library::Recycle_Input", "structParma__Polyhedra__Library_1_1Recycle__Input.html", null ],
      [ "Parma_Polyhedra_Library::Shape_Preserving_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Shape__Preserving__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Smash_Reduction< D1, D2 >", "classParma__Polyhedra__Library_1_1Smash__Reduction.html", null ],
      [ "Parma_Polyhedra_Library::Throwable", "classParma__Polyhedra__Library_1_1Throwable.html", null ],
      [ "Parma_Polyhedra_Library::Variable", "classParma__Polyhedra__Library_1_1Variable.html", null ],
      [ "Parma_Polyhedra_Library::Variables_Set", "classParma__Polyhedra__Library_1_1Variables__Set.html", null ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "Namespace List", "namespaces.html", [
      [ "Parma_Polyhedra_Library", "namespaceParma__Polyhedra__Library.html", null ],
      [ "Parma_Polyhedra_Library::IO_Operators", "namespaceParma__Polyhedra__Library_1_1IO__Operators.html", null ],
      [ "std", "namespacestd.html", null ]
    ] ],
    [ "Namespace Members", "namespacemembers.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

